'''
Create a Python function that takes a
string as input and returns the reverse of
that string. For example, if the input is "hello, " the function should return"olleh."
'''

def reverse_string(str): 
        return str[::-1]
     
str = input("Enter a String : ")
print(reverse_string(str))