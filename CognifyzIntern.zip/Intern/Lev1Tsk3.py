'''
Develop a Python function that validates whether a given string is a valid email address. Implement checks for the format,including the presence of an "@" symbol and a domain name
'''
'''
Develop a Python function that validates whether a given string is a valid email address. Implement checks for the format,including the presence of an "@" symbol and a domain name
'''
import re
def email_verifier(email):
    email_pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
    
    if re.match(email_pattern, email):
        return True
    else:
        return False
    
email = input("Please enter your email address: ")    
print(email_verifier(email))