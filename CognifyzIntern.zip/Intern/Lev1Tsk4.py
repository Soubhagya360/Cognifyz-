'''Create a Python program that acts as a basic calculator. It should prompt the user to enter two numbers and an operator (+, -,*, /, %) and then display the result of the operation.'''

num1 =  int(input("Enter one number : "))
num2 =  int(input("Enter another number : "))
operator = input("Enter operator : ")

match operator:
    case"+":
        print("The sum of the two numbers : ",num1 + num2)
    case"-":
        print("The difference of the two numbers : ",num1 - num2)
    case"*":
        print("The multiplication of the two numbers : ",num1 * num2)   
    case"/":
        print("The division of the two numbers : ",num1 / num2)
    case"%":
        print("The present value of the two numbers : ",num1 % num2)                    
