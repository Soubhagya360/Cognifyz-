''' Write a Python function that checks whether a given string is a palindrome. A palindrome is a word, phrase, or sequence that reads the same backward as forward (e.g.,"madam" or "racer"). '''

str = input("Enter a String : ")
original_str = str
reversed_str = ""
for i in str:
    reversed_str = i + reversed_str
print(reversed_str)
if original_str == reversed_str:
    print("The string is a palindrome !!")
else:
    print("The string is not a palindrome !!")