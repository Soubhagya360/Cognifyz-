''' Create a Python program that converts temperatures between Celsius and Fahrenheit. Prompt the user to enter a temperature value and the unit of measurement, and then display the converted temperature.
'''
temperature = float(input("Enter the temperature : "))
unit = input("Enter the unit of measurement : ")
if unit == "celsius":
    f = float( temperature * (9 / 5)) + 32
    print("The temperature in Fahrenheit : ",f)
elif unit == "fahrenheit":
    c = (temperature - 32) * 5/9
    print("The temperature in Celsius : ",c)