'''
Write a Python program that generates a random number between 1 and 100. The user should then try to guess the number.The program should provide hints such as "too high" or "too low" until the correct number is guessed.
'''
import random
# Generate a random number between 1 and 100
random_number = random.randint(1, 100)
guesses = 0
while True:
    guess = int(input("Guess a number between 1 and 100: "))
    guesses += 1
    if guess > random_number:
        print("Too high!")
    elif guess < random_number:
        print("Too low!")
    else:
        print(f"Congratulations! You guessed the correct number in {guesses} guesses.")
        break