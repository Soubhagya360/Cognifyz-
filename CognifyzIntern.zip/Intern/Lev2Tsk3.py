'''
Create a Python function that evaluates the strength of a password entered by the user. Implement checks for factors such as length, presence of uppercase and lowercase letters, digits, and special characters.
'''
import string
def passwordStrength(password):
    min_length = 8
    has_uppercase = any(char.isupper() for char in password)
    has_lowercase = any(char.islower() for char in password)
    has_digit = any(char.isdigit() for char in password)
    has_special_char = any(char in string.punctuation for char in password)

    strength = 0
    if len(password) >= min_length:
        strength += 1
    if has_uppercase:
        strength += 1
    if has_lowercase:
        strength += 1
    if has_digit:
        strength += 1
    if has_special_char:
        strength += 1
    return strength

user_password = input("Enter your password: ")
strength = passwordStrength(user_password)

if strength == 5:
    print("Password is very strong!")
elif strength >= 3:
    print("Password is strong.")
elif strength >= 2:
    print("Password is moderate.")
else:
    print("Password is weak. Please consider improving it.")