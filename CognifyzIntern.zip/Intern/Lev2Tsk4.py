'''
Write a Python function that generates the Fibonacci sequence up to a given number of terms. The function should take an integer input from the user and display the Fibonacci sequence up to that number of terms.
'''
def fibonacci_sequence(n):
  if n <= 0:
    print("Number of terms must be a positive integer.")
  series = []
  a, b = 0, 1
  for _ in range(n):
    series.append(a)
    a, b = b, a + b
  return series
n = int(input("Enter the number : "))
print(f"Fibonacci sequence: {fibonacci_sequence(n)}")