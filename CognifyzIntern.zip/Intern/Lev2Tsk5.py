'''
Write a Python program that reads a text file and counts the occurrences of each word in the file. Display the results in alphabetical order along with their respective counts.
'''
import collections
file = open("D:\Intern\hello.txt","r")
count = 0
for line in file:
    words = line.split(" ")
    count += len(words)
file. close()
print("Number of words in the Text File : ",count)